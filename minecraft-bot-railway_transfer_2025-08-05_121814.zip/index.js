const mineflayer = require('mineflayer');
const { pathfinder, Movements, goals } = require('mineflayer-pathfinder');
const express = require('express');

const app = express();
app.get('/', (req, res) => res.send('Bot is running'));
app.listen(3000, () => console.log('Express aktif di port 3000'));

const bot = mineflayer.createBot({
  host: 'alwination.id',
  port: 25565,
  username: 'Ciaa',
});

bot.once('spawn', () => {
  console.log(`[✓] Bot masuk ke server sebagai: ${bot.username}`);
  bot.loadPlugin(pathfinder);

  // Login ke AuthMe
  setTimeout(() => {
    bot.chat('/login ica999');
    console.log('[+] Login dikirim.');

    // Masuk ke earth1
    setTimeout(() => {
      bot.chat('/move earth1');
      console.log('[+] Masuk ke earth1 dikirim.');

      // Tunggu map selesai dimuat lalu jalan ke NPC
      setTimeout(() => {
        jalanKeNPC(102, 92, -191);
      }, 5000);
    }, 3000);
  }, 3000);
});

function jalanKeNPC(x, y, z) {
  const mcData = require('minecraft-data')(bot.version);
  const defaultMove = new Movements(bot, mcData);
  bot.pathfinder.setMovements(defaultMove);
  const goal = new goals.GoalBlock(x, y, z);
  bot.pathfinder.setGoal(goal);

  bot.once('goal_reached', () => {
    console.log('[✓] Bot sampai di koordinat NPC.');
    const npc = bot.nearestEntity(entity => entity.type === 'player' || entity.type === 'mob');
    if (npc) {
      bot.attack(npc, true);
      console.log('[+] Bot klik kiri ke NPC.');
    } else {
      console.log('[!] Tidak menemukan NPC di dekat bot.');
    }
  });
}

// Periksa chat dan auto /tpaccept jika nama VenxZzz muncul
bot.on('chat', (username, message) => {
  if (message.toLowerCase().includes('venxzzz')) {
    bot.chat('/tpaccept');
    console.log('[✓] Perintah /tpaccept dikirim karena terlihat nama VenxZzz.');
  }
});

bot.on('error', err => console.log('[!] Error:', err));
bot.on('end', () => console.log('[!] Bot disconnected'));